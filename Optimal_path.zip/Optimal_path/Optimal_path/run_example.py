
import json
from pathlib import Path
from src.astar import astar
from src.utils import haversine_km

graph_path = Path("data/graph.json")
graph = json.loads(graph_path.read_text(encoding="utf-8"))

START = graph.get("start", "Home")
GOAL = graph.get("goal", "UAP")

def build_heuristic(graph, goal):
    glat = graph["nodes"][goal]["lat"]
    glon = graph["nodes"][goal]["lon"]
    def h(n):
        lat = graph["nodes"][n]["lat"]
        lon = graph["nodes"][n]["lon"]
        return haversine_km(lat, lon, glat, glon)
    return h

h = build_heuristic(graph, GOAL)
path, cost_km, explored = astar(graph, START, GOAL, h)

if path is None:
    print("No path found from", START, "to", GOAL)
else:
    print("Optimal path:", " -> ".join(path))
    print(f"Optimal cost g(n): {cost_km:.3f} km")
    print(f"Nodes explored: {explored}")
