
from heapq import heappush, heappop

def astar(graph, start, goal, h):
    open_heap = []
    heappush(open_heap, (0.0, start))
    came_from = {}
    g = {start: 0.0}
    f = {start: h(start)}
    closed = set()
    explored_count = 0

    while open_heap:
        _, current = heappop(open_heap)
        if current in closed:
            continue
        closed.add(current)
        explored_count += 1
        if current == goal:
            path = [current]
            while current in came_from:
                current = came_from[current]
                path.append(current)
            path.reverse()
            return path, g[path[-1]], explored_count

        for nbr, w in graph["edges"].get(current, {}).items():
            tentative_g = g[current] + float(w)
            if tentative_g < g.get(nbr, float("inf")):
                came_from[nbr] = current
                g[nbr] = tentative_g
                f[nbr] = tentative_g + h(nbr)
                heappush(open_heap, (f[nbr], nbr))

    return None, float("inf"), explored_count
